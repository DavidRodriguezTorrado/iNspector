package logine.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

/**
 * Servlet implementation class Programar_inspeccion
 */
@WebServlet("/Programar_inspeccion")
public class Programar_inspeccion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Programar_inspeccion() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String local = request.getParameter("local");
		String comentarios = request.getParameter("comentarios");
		String nrp = request.getParameter("inspector");
		
		try {
			DateFormat format = new SimpleDateFormat("dd LL yyyy");
			Date fecha = format.parse(request.getParameter("date"));
			Date date = new Date();
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con;
			String url = "jdbc:mysql://localhost/test1";
			String user = "dbadmin";
			String pw = "tortuga";
			con = DriverManager.getConnection(url, user, pw);
			Statement s = con.createStatement();
			
			ResultSet rs = s.executeQuery("SELECT id FROM locales WHERE id= '" +local+ "'");
			
			if(rs.next() && fecha.after(date)) {
				
				String query = "INSERT INTO inspecciones_programadas " + "(fecha, id_local, comentarios, inspector) " + "VALUES ('" + fecha + "', '" + rs.getInt(1) + "', '" + comentarios + "','" + nrp + "')";
				s.executeUpdate(query);
				con.close();
				
				getServletContext()
				.getRequestDispatcher("/Bien_Programar_Inspeccion.jsp")
				.forward(request,response);
				
		     }else {
		    	getServletContext()
				.getRequestDispatcher("/Mal_Programar_Inspeccion.jsp")
				.forward(request,response);
		     }
			}
		catch(ClassNotFoundException e){
			 e.printStackTrace();
		}catch(SQLException e){
			 e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}
