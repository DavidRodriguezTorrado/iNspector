package logine.registration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 * Servlet implementation class LoginInspector
 */
@WebServlet("/LoginInspector")
public class LoginInspector extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginInspector() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = "";
		String NRP = request.getParameter("NRP");
		String password = request.getParameter("password");
		String mail = "";
		
		try {
			Inspector insp = new Inspector(name, password, NRP, mail);
			request.setAttribute("insp", insp);
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con;
			String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			String user = "dbadmin";
			String pw = "tortuga";
			con = DriverManager.getConnection(url, user, pw);
			Statement s = con.createStatement();
			ResultSet res = s.executeQuery("SELECT * FROM INSPECTORES WHERE NRP= '" +NRP+"' and contraseña= '" + password+ "'");
			if(res.next()) {
				res.first();
				insp.setName(res.getString(1));
				insp.setPassword(res.getString(2));
				insp.setNRP(res.getString(3));
				insp.setMail(res.getString(4));
				request.getSession().setAttribute("NombreInspector",res.getString(1));
				request.getSession().setAttribute("NRPInspector",res.getString(3));
				request.getSession().setAttribute("MailInspector",res.getString(4));
				request.getSession().setAttribute("PasswordInspector",res.getString(2));
				request.getSession().setAttribute("Registrado","inspector");
				
				request.setAttribute("insp", insp);
				getServletContext()
				.getRequestDispatcher("/Conf-Inspector.jsp")
				.forward(request,response);
		      }else {
		    	 getServletContext()
				.getRequestDispatcher("/MalLog.jsp")
				.forward(request,response);

		}
	}
		catch(ClassNotFoundException e){
			 e.printStackTrace();
		 } catch(SQLException e){
			 e.printStackTrace();
		
		 }
	}

}
