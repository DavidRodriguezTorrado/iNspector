package logine.registration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class LoginRegisterInspector
 */
@WebServlet("/LoginRegisterInspector")
public class LoginRegisterInspector extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginRegisterInspector() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String NRP = request.getParameter("NRP");
		String password = request.getParameter("password");
		String mail = request.getParameter("mail");
		
		try {
			Inspector insp = new Inspector(name, password, NRP, mail);
			request.setAttribute("insp", insp);
			 Connection con;
			 Class.forName("com.mysql.cj.jdbc.Driver");
			 String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			 String user = "dbadmin";
			 String pw = "tortuga";
			 con = DriverManager.getConnection(url, user, pw);
			 Statement s = con.createStatement();
			 PreparedStatement ps= con.prepareStatement("INSERT INTO INSPECTORES " +
					 		"(nombre, contraseña, NRP, email) " +
					 		"VALUES ('" + name + "', '" + password + "', '" + NRP + "', '" + mail + "')");
			 ps.executeUpdate();
			 ResultSet res = s.executeQuery("SELECT * FROM INSPECTORES WHERE NRP= '" +NRP+"'");
			 
			 res.first();
			 insp.setName(res.getString(1));
			 insp.setNRP(res.getString(3));
			 insp.setPassword(res.getString(2));
			 insp.setMail(res.getString(4));
			 request.getSession().setAttribute("NombreInspector",res.getString(1));
			 request.getSession().setAttribute("NRPInspector",res.getString(3));
			 request.getSession().setAttribute("MailInspector",res.getString(4));
			 request.getSession().setAttribute("PasswordInspector",res.getString(2));
			 request.getSession().setAttribute("Registrado","inspector");
			 request.setAttribute("insp", insp);
			 getServletContext()
				.getRequestDispatcher("/Conf-Inspector.jsp")
				.forward(request,response);
	}catch(ClassNotFoundException e){
		 e.printStackTrace();
	 } catch(SQLException e){
		 e.printStackTrace();
	 }
	}
}
