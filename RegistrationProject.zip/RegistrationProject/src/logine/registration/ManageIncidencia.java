package logine.registration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 * Servlet implementation class ManageIncidencia
 */
@WebServlet("/ManageIncidencia")
public class ManageIncidencia extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ManageIncidencia() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String date = request.getParameter("date");
		String local = request.getParameter("local");
		String tipo = request.getParameter("tipo");
		String customer = request.getParameter("customer");
		String inspector = request.getParameter("inspector");
		String inspected = "No";
		String comentarios = request.getParameter("comentarios");
		String resultado = "-";
		 try {
			 Incidencia inc = new Incidencia(date, local, tipo, customer, inspector, inspected, comentarios, resultado);
			 request.setAttribute("inc", inc);
			 Connection con;
			 Class.forName("com.mysql.cj.jdbc.Driver");
			 String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			 String user = "dbadmin";
			 String pw = "tortuga";
			 con = DriverManager.getConnection(url, user, pw);
			 Statement s = con.createStatement();
			 PreparedStatement ps = con.prepareStatement("INSERT INTO INCIDENCIA " +
					 		"(date, local, tipo, customer, inspector, inspected, comentarios, resultado, inc_id) " +
					 		"VALUES ('" + date + "', '" + local + "', '" + tipo + "', '" + customer + "', '" + inspector + "', '" + inspected + "', '" + comentarios + "', '" + resultado + "', NULL)");
			 ps.executeUpdate();
			 ResultSet res = s.executeQuery("SELECT * FROM INCIDENCIA WHERE local= '" +local+"' and customer= '" + customer+ "'");
			 
			 res.first();;
			 inc.setDate(res.getString(1));
			 inc.setLocal(res.getString(2));
			 inc.setTipo(res.getString(3));
			 inc.setCustomer(res.getString(4));
			 inc.setInspector(res.getString(5));
			 inc.setInspected(res.getString(6));
			 inc.setComentarios(res.getString(7));
			 inc.setResultado(res.getString(8));
			 
			 request.getSession().setAttribute("Date",res.getString(1));
			 request.getSession().setAttribute("Local",res.getString(2));
			 request.getSession().setAttribute("Tipo",res.getString(3));
			 request.getSession().setAttribute("Customer",res.getString(4));
			 request.getSession().setAttribute("Inspector",res.getString(5));
			 request.getSession().setAttribute("Inspected",res.getString(6));
			 request.getSession().setAttribute("Comentarios",res.getString(7));
			 request.getSession().setAttribute("Resultado",res.getString(7));
				getServletContext()
				.getRequestDispatcher("/BienIncidencia.jsp")
				.forward(request,response);
			 
		 } catch(ClassNotFoundException e){
			 e.printStackTrace();
		 } catch(SQLException e){
			 e.printStackTrace();
		 }
	}

}
