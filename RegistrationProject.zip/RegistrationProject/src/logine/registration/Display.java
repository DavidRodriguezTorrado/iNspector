package logine.registration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


/**
 * Servlet implementation class Display
 */
@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Display() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String rotulo = request.getParameter("rotulo");
		if(rotulo==null) {
		rotulo =(String)request.getSession().getAttribute("rotulo");
		}
		String username =(String)request.getSession().getAttribute("Usuario");
		try {
		Inspeccion local = new Inspeccion();
		request.setAttribute("local", local);
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con;
		String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
		String user = "dbadmin";
		String pw = "tortuga";	
		con = DriverManager.getConnection(url, user, pw);
		Statement s = con.createStatement();
		String query = "SELECT * FROM inspecciones_isst WHERE rótulo = '" + rotulo + "' ORDER BY Fecha_de_la_inspección";
		
		ResultSet res = s.executeQuery(query);
		if(res.next()) {
		String reg=(String)request.getSession().getAttribute("Registrado");
		res.first();
		local.setId(res.getInt(1));
		local.setRotulo(res.getString(2));
		local.setDireccion(res.getString(3));
		local.setActividad(res.getString(4));
		local.setFecha(res.getString(5));
		local.setTipo_actuacion(res.getString(6));
		local.setPerfil_actividad(res.getString(7));
		local.setEstado_sanitario(res.getString(8));
		local.setF_inspeccion(res.getString(9));
		
		if(reg=="si") {

		 
		Customer cust = new Customer("","" ,username , "", "", "", "", "", "", "" );
		Statement s4 = con.createStatement();
		 ResultSet res4 = s4.executeQuery("SELECT ult1, ult2, ult3 FROM CUSTOMER WHERE username= '" +username+"'");
		 if(res4.next()) {
		 cust.setUlt1(res4.getString(1));
		 cust.setUlt2(res4.getString(2));
		 cust.setUlt3(res4.getString(3));
		 String ultimo1 = cust.getUlt1();
		 String ultimo2 = cust.getUlt2();
		 String ultimo3 = cust.getUlt3();
		 request.getSession().setAttribute("ult1", " ");
		 request.getSession().setAttribute("ult2", " ");
		 request.getSession().setAttribute("ult3", " ");
		 
			if(ultimo1== "NULL" && ultimo2== "NULL" && ultimo3 == "NULL") {
					PreparedStatement ps = con.prepareStatement("UPDATE customer SET ult1='"+rotulo+"'" 
							+ "WHERE username='"+username+"'");
					ps.executeUpdate();
					Statement s1 = con.createStatement();
					 
						 request.getSession().setAttribute("ult1", local.getRotulo());
					ResultSet res1 = s1.executeQuery("SELECT * FROM CUSTOMER WHERE username= '" +username+"'");
					if(res1.next()) {
					res1.first();
					cust.setName(res1.getString(1));
					 cust.setUsername(res1.getString(3));
					 cust.setPassword(res1.getString(2));
					 cust.setMail(res1.getString(4));
					 cust.setCust_id(res1.getInt(5));
					 cust.setFav1(res1.getString(6));
					 cust.setFav2(res1.getString(7));
					 cust.setFav3(res1.getString(8));
					 cust.setUlt1(res1.getString(9));
					 cust.setUlt2("");
					 cust.setUlt3("");
					 request.getSession().setAttribute("ult2", " ");
					 request.getSession().setAttribute("ult3", " ");
					}	 
			 }
			 if(ultimo2 == "NULL" && ultimo3 == "NULL") {
				 Statement s2 = con.createStatement();
				 ResultSet res2 = s2.executeQuery("SELECT ult1 FROM CUSTOMER WHERE username= '" +username+"'");
				 if(res2.next()) {
				 cust.setUlt2(res2.getString(1));
				 PreparedStatement ps2 = con.prepareStatement("UPDATE customer SET ult2='"+cust.getUlt2()+"'" 
							+ "WHERE username='"+username+"'");
					ps2.executeUpdate();
				 res2.first();
				 request.getSession().setAttribute("ult1", local.getRotulo());
				 PreparedStatement ps = con.prepareStatement("UPDATE customer SET ult1='"+rotulo+"'" 
							+ "WHERE username='"+username+"'");
					ps.executeUpdate();
					
					
					Statement s1 = con.createStatement();
					 
					request.getSession().setAttribute("ult1", local.getRotulo());
					
					ResultSet res1 = s1.executeQuery("SELECT * FROM CUSTOMER WHERE username= '" +username+"'");
					if(res1.next()) {
					res1.first();
					cust.setName(res1.getString(1));
					 cust.setUsername(res1.getString(3));
					 cust.setPassword(res1.getString(2));
					 cust.setMail(res1.getString(4));
					 cust.setCust_id(res1.getInt(5));
					 cust.setFav1(res1.getString(6));
					 cust.setFav2(res1.getString(7));
					 cust.setFav3(res1.getString(8));
					 cust.setUlt1(res1.getString(9));
					 cust.setUlt2(res1.getString(10));
					 cust.setUlt3("");
					 
					 request.getSession().setAttribute("ult2", res1.getString(10));
					 request.getSession().setAttribute("ult3", "");
					}
				 }
			 }
			 if(ultimo3 == "NULL" || (ultimo1 != "NULL" && ultimo2 != "NULL" && ultimo3 != "NULL")) {
				 Statement s3 = con.createStatement();
				 ResultSet res3 = s3.executeQuery("SELECT ult2 FROM CUSTOMER WHERE username= '" +username+"'");
				 if(res3.next()) {
				 cust.setUlt3(res3.getString(1));
				 PreparedStatement ps3 = con.prepareStatement("UPDATE customer SET ult3='"+cust.getUlt3()+"'" 
							+ "WHERE username='"+username+"'");
					ps3.executeUpdate();
				 
				 Statement s2 = con.createStatement();
				 ResultSet res2 = s2.executeQuery("SELECT ult1 FROM CUSTOMER WHERE username= '" +username+"'");
				 if(res2.next()) {
				 cust.setUlt2(res2.getString(1));
				 PreparedStatement ps2 = con.prepareStatement("UPDATE customer SET ult2='"+cust.getUlt2()+"'" 
							+ "WHERE username='"+username+"'");
					ps2.executeUpdate();
				 res2.first();
				 
				 request.getSession().setAttribute("ult1", local.getRotulo());
				 PreparedStatement ps = con.prepareStatement("UPDATE customer SET ult1='"+rotulo+"'" 
							+ "WHERE username='"+username+"'");
					ps.executeUpdate();
					
					
					Statement s1 = con.createStatement();
					 
					request.getSession().setAttribute("ult1", local.getRotulo());
					ResultSet res1 = s1.executeQuery("SELECT * FROM CUSTOMER WHERE username= '" +username+"'");
					if(res1.next()) {
					res1.first();
					cust.setName(res1.getString(1));
					 cust.setUsername(res1.getString(3));
					 cust.setPassword(res1.getString(2));
					 cust.setMail(res1.getString(4));
					 cust.setCust_id(res1.getInt(5));
					 cust.setFav1(res1.getString(6));
					 cust.setFav2(res1.getString(7));
					 cust.setFav3(res1.getString(8));
					 cust.setUlt1(res1.getString(9));
					 cust.setUlt2(res1.getString(10));
					 cust.setUlt3(res1.getString(11));
					 
					 request.getSession().setAttribute("ult2", res1.getString(10));
					 request.getSession().setAttribute("ult3", res1.getString(11));
					}
					}
			 }
			 }
			 
			getServletContext()
			.getRequestDispatcher("/Buscador-Usuario.jsp")
			.forward(request, response);
			}
		}
		
		else if(reg=="no") {
			getServletContext()
			.getRequestDispatcher("/Buscador-Usuario.jsp")
			.forward(request, response);
			
		}
		else if(reg=="inspector") {
			getServletContext()
			.getRequestDispatcher("/Buscador-Inspector.jsp")
			.forward(request, response);
			
		}

			
			con.close();
		}
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
		
	}

}
