package logine.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Display_inspecciones_inspector")
public class Display_inspecciones_inspector extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Display_inspecciones_inspector() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String npr = request.getParameter("inspector");	
		
		try {
			Connection con;
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			String user = "dbadmin";
			String pw = "tortuga";
			con = DriverManager.getConnection(url, user, pw);
			Statement s = con.createStatement();
			
			String query = "SELECT inspecciones_isst_id, rotulo, direccion, fecha FROM inspecciones_isst WHERE inspector='" + npr + "' ORDER BY fecha";
			ResultSet res = s.executeQuery(query);
			
			int loop = 0;
			int size = 0;
			if (res != null) 
			{
			  res.last();
			  size = res.getRow();
			}

			int[] id;
			id = new int[size];
			String[] fecha;
			fecha = new String[size];
			String[] rotulo;
			rotulo = new String[size];
			String[] direccion;
			direccion = new String[size];
			
			res.first();
			do {
				id[loop] = res.getInt(1);
				rotulo[loop] = res.getString(2);
				direccion[loop] = res.getString(3);
				fecha[loop] = res.getString(4);
				loop++;
			} while(res.next());
			
			con.close();
			
			request.setAttribute("id", id);
			request.setAttribute("fecha", fecha);
			request.setAttribute("rotulo", rotulo);
			request.setAttribute("direccion", direccion);
			
			getServletContext()
			.getRequestDispatcher("/Display_inspecciones_inspector.jsp")
			.forward(request, response);
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
					
	}

}
