package logine.registration;

import java.io.Serializable;

public class Inspector implements Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private String password;
	private String NRP;
	private String mail;
	
	public Inspector() {
		this.name="";
		this.password="";
		this.NRP="";
		this.mail="";
	}
	public Inspector(String name, String password, String NRP, String mail) {
		this.name=name;
		this.password=password;
		this.NRP=NRP;
		this.mail=mail;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNRP() {
		return NRP;
	}
	public void setNRP(String nRP) {
		NRP = nRP;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}



}
