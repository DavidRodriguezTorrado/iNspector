package logine.registration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = "";
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String mail = "";
		String fav1 = "";
		String fav2 = "";
		String fav3 = "";
		String ult1 = "";
		String ult2 = "";
		String ult3 = "";
		
		
		try {
			Customer cust = new Customer(name, password, username, mail, fav1, fav2, fav3, ult1, ult2, ult3);
			request.setAttribute("cust", cust);
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con;
			String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			String user = "dbadmin";
			String pw = "tortuga";
			con = DriverManager.getConnection(url, user, pw);
			Statement s = con.createStatement();
			ResultSet res = s.executeQuery("SELECT * FROM CUSTOMER WHERE username= '" +username+"' and password= '" + password+ "'");
			if(res.next()) {
				res.first();
				cust.setName(res.getString(1));
				 cust.setUsername(res.getString(3));
				 cust.setPassword(res.getString(2));
				 cust.setMail(res.getString(4));
				 cust.setCust_id(res.getInt(5));
				 cust.setFav1(res.getString(6));
				 cust.setFav2(res.getString(7));
				 cust.setFav3(res.getString(8));
				 cust.setUlt1(res.getString(9));
				 cust.setUlt2(res.getString(10));
				 cust.setUlt3(res.getString(11));
				 request.getSession().setAttribute("Nombre",cust.getName());
				 request.getSession().setAttribute("Usuario",res.getString(3));
				 request.getSession().setAttribute("Mail",res.getString(4));
				 request.getSession().setAttribute("Password",res.getString(2));
				 request.getSession().setAttribute("Registrado","si");
				 request.getSession().setAttribute("ult1",res.getString(9));
				 request.getSession().setAttribute("ult2",res.getString(10));
				 request.getSession().setAttribute("ult3",res.getString(11));
				getServletContext()
				.getRequestDispatcher("/Conf-Usuario.jsp")
				.forward(request,response);
		      }else {
		    	 getServletContext()
				.getRequestDispatcher("/MalLog.jsp")
				.forward(request,response);

		}
	}
		catch(ClassNotFoundException e){
			 e.printStackTrace();
		 } catch(SQLException e){
			 e.printStackTrace();
		
		 }

	}

}
