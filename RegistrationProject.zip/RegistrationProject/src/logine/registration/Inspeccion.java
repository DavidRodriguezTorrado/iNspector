package logine.registration;

public class Inspeccion {
	private int id;
	private String rotulo;
	private String direccion;
	private String actividad;
	private String fecha;
	private String tipo_actuacion;
	private String perfil_actividad;
	private String estado_sanitario;
	private String f_inspeccion;
	
	
	public Inspeccion() {
		this.id = 0;
		this.rotulo = "";
		this.direccion = "";
		this.actividad = "";
		this.fecha = "";
		this.tipo_actuacion = "";
		this.perfil_actividad = "";
		this.estado_sanitario = "";
		this.f_inspeccion = "";
	}

	public Inspeccion(int id, String rotulo, String direccion, String actividad, String fecha, String tipo_actuacion,
			String perfil_actividad, String estado_sanitario, String f_inspeccion) {
		this.id = id;
		this.rotulo = rotulo;
		this.direccion = direccion;
		this.actividad = actividad;
		this.fecha = fecha;
		this.tipo_actuacion = tipo_actuacion;
		this.perfil_actividad = perfil_actividad;
		this.estado_sanitario = estado_sanitario;
		this.f_inspeccion = f_inspeccion;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRotulo() {
		return rotulo;
	}
	public void setRotulo(String rotulo) {
		this.rotulo = rotulo;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getActividad() {
		return actividad;
	}
	public void setActividad(String actividad) {
		this.actividad = actividad;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getTipo_actuacion() {
		return tipo_actuacion;
	}
	public void setTipo_actuacion(String tipo_actuacion) {
		this.tipo_actuacion = tipo_actuacion;
	}
	public String getPerfil_actividad() {
		return perfil_actividad;
	}
	public void setPerfil_actividad(String perfil_actividad) {
		this.perfil_actividad = perfil_actividad;
	}
	public String getEstado_sanitario() {
		return estado_sanitario;
	}
	public void setEstado_sanitario(String estado_sanitario) {
		this.estado_sanitario = estado_sanitario;
	}
	public String getF_inspeccion() {
		return f_inspeccion;
	}
	public void setF_inspeccion(String f_inspeccion) {
		this.f_inspeccion = f_inspeccion;
	}
	
	
	
}
