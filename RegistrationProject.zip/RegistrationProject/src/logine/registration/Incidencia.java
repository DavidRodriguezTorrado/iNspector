package logine.registration;

import java.io.Serializable;

public class Incidencia implements Serializable {

	private static final long serialVersionUID = 1L;
	private String date;
	private String local;
	private String tipo;
	private String customer;
	private String inspector;
	private String inspected;
	private String comentarios;
	private String resultado;
	
	public Incidencia() {
		this.setDate("");
		this.setLocal("");
		this.setTipo("");
		this.setCustomer("");
		this.setInspector("");
		this.setInspected("");
		this.setComentarios("");
		this.setResultado("");
		
	}
	public Incidencia(String date, String local, String tipo, String customer, String inspector, String inspected, String comentarios, String resultado) {
		this.setDate(date);
		this.setLocal(local);
		this.setTipo(tipo);
		this.setCustomer(customer);
		this.setInspector(inspector);
		this.setInspected(inspected);
		this.setComentarios(comentarios);
		this.setResultado(comentarios);
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getInspector() {
		return inspector;
	}
	public void setInspector(String inspector) {
		this.inspector = inspector;
	}
	public String getInspected() {
		return inspected;
	}
	public void setInspected(String inspected) {
		this.inspected = inspected;
	}
	public String getComentarios() {
		return comentarios;
	}
	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}
	public String getResultado() {
		return resultado;
	}
	public void setResultado(String resultados) {
		this.resultado = resultados;
	}


}
