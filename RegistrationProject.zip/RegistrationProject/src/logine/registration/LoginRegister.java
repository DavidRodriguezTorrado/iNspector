package logine.registration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 * Servlet implementation class LoginRegister
 */
@WebServlet("/LoginRegister")
public class LoginRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginRegister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name5");
		String username = request.getParameter("username5");
		String password = request.getParameter("password5");
		String mail = request.getParameter("mail5");
		String fav1 = "";
		String fav2 = "";
		String fav3 = "";
		String ult1 = "";
		String ult2 = "";
		String ult3 = "";
		
		 try {
			 Customer cust = new Customer(name, password, username, mail, fav1, fav2, fav3, ult1, ult2, ult3);
			 request.setAttribute("cust", cust);
			 Connection con;
			 Class.forName("com.mysql.cj.jdbc.Driver");
			 String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			 String user = "dbadmin";
			 String pw = "tortuga";
			 con = DriverManager.getConnection(url, user, pw);
			 Statement s = con.createStatement();
			 PreparedStatement ps =con.prepareStatement("INSERT INTO CUSTOMER " +
					 		"(name, password, username, mail, cust_id) " +
					 		"VALUES ('" + name + "', '" + password + "', '" + username + "', '" + mail + "', NULL)");
			 ps.executeUpdate();
			 ResultSet res = s.executeQuery("SELECT * FROM CUSTOMER WHERE name= '" +name+"'");
			 
			 res.first();
			 cust.setName(res.getString(1));
			 cust.setUsername(res.getString(3));
			 cust.setPassword(res.getString(2));
			 cust.setMail(res.getString(4));
			 cust.setCust_id(res.getInt(5));
			 cust.setFav1(res.getString(6));
			 cust.setFav2(res.getString(7));
			 cust.setFav3(res.getString(8));
			 cust.setUlt1(res.getString(9));
			 cust.setUlt2(res.getString(10));
			 cust.setUlt3(res.getString(11));
			 request.getSession().setAttribute("Nombre",cust.getName());
			 request.getSession().setAttribute("Usuario",res.getString(3));
			 request.getSession().setAttribute("Mail",res.getString(4));
			 request.getSession().setAttribute("Password",res.getString(2));
			 request.getSession().setAttribute("Registrado","si");
			 request.getSession().setAttribute("ult1",res.getString(9));
			 request.getSession().setAttribute("ult2",res.getString(10));
			 request.getSession().setAttribute("ult3",res.getString(11));
			 request.setAttribute("cust", cust);
				getServletContext()
				.getRequestDispatcher("/Conf-Usuario.jsp")
				.forward(request,response);
			 
		 } catch(ClassNotFoundException e){
			 e.printStackTrace();
		 } catch(SQLException e){
			 e.printStackTrace();
		 }
	}
}

