package logine.registration;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Modificar_inspeccion_programada
 */
@WebServlet("/Modificar_inspeccion_programada")
public class Modificar_inspeccion_programada extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Modificar_inspeccion_programada() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String id = request.getParameter("id");
		String fecha = request.getParameter("fecha");
		String local = request.getParameter("local");
		String direccion = request.getParameter("direccion");
		String comentarios = request.getParameter("comentarios");
		
		request.setAttribute("id", id);
		request.setAttribute("fecha", fecha);
		request.setAttribute("local", local);
		request.setAttribute("direccion", direccion);
		request.setAttribute("comentarios", comentarios);
		
		getServletContext()
		.getRequestDispatcher("/Modificar_inspeccion_programada.jsp")
		.forward(request,response);
	}

}