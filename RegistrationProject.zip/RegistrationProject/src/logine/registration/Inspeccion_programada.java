package logine.registration;

import java.io.Serializable;

public class Inspeccion_programada implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int id;
	private String fecha;
	private int id_local;
	private String comentarios;
	private String inspector;
	private String rotulo;
	private String direccion;
	
	public Inspeccion_programada() {
		super();
	}

	public Inspeccion_programada(int id, String fecha, int id_local, String comentarios, String inspector) {
		super();
		this.id = id;
		this.fecha = fecha;
		this.id_local = id_local;
		this.comentarios = comentarios;
		this.inspector = inspector;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public int getId_local() {
		return id_local;
	}

	public void setId_local(int id_local) {
		this.id_local = id_local;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	public String getInspector() {
		return inspector;
	}

	public void setInspector(String inspector) {
		this.inspector = inspector;
	}

	public String getRotulo() {
		return rotulo;
	}

	public void setRotulo(String rotulo) {
		this.rotulo = rotulo;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

}
