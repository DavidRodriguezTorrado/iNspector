package logine.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DisplayInspeccionesProgramadas
 */
@WebServlet("/DisplayInspeccionesProgramadas")
public class DisplayInspeccionesProgramadas extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DisplayInspeccionesProgramadas() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sesion= (HttpSession) request.getSession();
		String nrp= (String) sesion.getAttribute("NRP");
		
		try {	
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con;
			String url = "jdbc:mysql://localhost/test1?serverTimezone=UTC";
			String user = "dbadmin";
			String pw = "tortuga";
			con = DriverManager.getConnection(url, user, pw);
			Statement s = con.createStatement();
			Statement s2 = con.createStatement();
			
			ResultSet rs = s.executeQuery("SELECT id, fecha, id_local, comentarios FROM inspecciones_programadas WHERE inspector= '" +nrp+ "' order by fecha");
			
			int loop = 0;
			int size = 0;
			if (rs != null) 
			{
			  rs.last();
			  size = rs.getRow();
			}

			int[] id;
			id = new int[size];
			String[] fecha;
			fecha = new String[size];
			String[] comentarios;
			comentarios = new String[size];
			String[] rotulo;
			rotulo = new String[size];
			String[] direccion;
			direccion = new String[size];
	
			if (rs.first()) {
				do {
					id[loop] = rs.getInt(1);
					fecha[loop] = rs.getString(2);
					comentarios[loop] = rs.getString(4);
					ResultSet res = s2.executeQuery("SELECT rotulo, direccion FROM locales WHERE id= '" +rs.getInt(3)+ "'");
					res.next();
					rotulo[loop] = res.getString(1);
					direccion[loop] = res.getString(2);
					loop++;
				} while(rs.next());
				
				con.close();
				
				request.setAttribute("id", id);
				request.setAttribute("fecha", fecha);
				request.setAttribute("comentarios", comentarios);
				request.setAttribute("rotulo", rotulo);
				request.setAttribute("direccion", direccion);
				
				getServletContext()
				.getRequestDispatcher("/Inspecciones_programadas.jsp")
				.forward(request,response);
			}
		}
		catch(ClassNotFoundException e){
			 e.printStackTrace();
		}catch(SQLException e){
			 e.printStackTrace();
		}
	}

}
