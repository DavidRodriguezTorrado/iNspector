package logine.registration;

import java.io.Serializable;

public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private String password;
	private String username;
	private String mail;
	private int cust_id;
	private String fav1;
	private String fav2;
	private String fav3;
	private String ult1;
	private String ult2;
	private String ult3;
	
	public Customer() {
		this.name="";
		this.password="";
		this.username="";
		this.mail="";
		this.setCust_id(0);
		this.setFav1("");
		this.setFav2("");
		this.setFav3("");
		this.setUlt1("");
		this.setUlt2("");
		this.setUlt3("");
		
	}
	public Customer(String name, String password, String username, String mail,String fav1, String fav2, String fav3, String ult1, String ult2, String ult3) {
		this.name=name;
		this.password=password;
		this.username=username;
		this.mail=mail;
		this.setCust_id(cust_id);
		this.setFav1(fav1);
		this.setFav2(fav2);
		this.setFav3(fav3);
		this.setUlt1(ult1);
		this.setUlt2(ult2);
		this.setUlt3(ult3);
		
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getFav1() {
		return fav1;
	}
	public void setFav1(String fav1) {
		this.fav1 = fav1;
	}
	public String getFav2() {
		return fav2;
	}
	public void setFav2(String fav2) {
		this.fav2 = fav2;
	}
	public String getFav3() {
		return fav3;
	}
	public void setFav3(String fav3) {
		this.fav3 = fav3;
	}
	public String getUlt1() {
		return ult1;
	}
	public void setUlt1(String ult1) {
		this.ult1 = ult1;
	}
	public String getUlt2() {
		return ult2;
	}
	public void setUlt2(String ult2) {
		this.ult2 = ult2;
	}
	public String getUlt3() {
		return ult3;
	}
	public void setUlt3(String ult3) {
		this.ult3 = ult3;
	}
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

}
