package logine.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


/**
 * Servlet implementation class Display
 */
@WebServlet("/MisDatos")
public class MisDatos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MisDatos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username =(String)request.getSession().getAttribute("Usuario");
		String newname = request.getParameter("name1");
		String newusername = request.getParameter("username1");
		String newmail = request.getParameter("mail1");
		String newpassword = request.getParameter("password1");
		String fav1 = "";
		String fav2 = "";
		String fav3 = "";
		String ult1 = "";
		String ult2 = "";
		String ult3 = "";
		
		try {
			Customer cust = new Customer(newname, newpassword, newusername, newmail, fav1, fav2, fav3, ult1, ult2, ult3 );
			request.setAttribute("cust", cust);
			Connection con;
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			String user = "dbadmin";
			String pw = "tortuga";
			con = DriverManager.getConnection(url, user, pw);
			PreparedStatement ps = con.prepareStatement("UPDATE customer SET name='"+newname+"', username='"+newusername+"',mail='"+newmail+"', password='"+newpassword+"'" 
					+ "WHERE username='"+username+"'");
			ps.executeUpdate();

			Statement s = con.createStatement();
			ResultSet res = s.executeQuery("SELECT * FROM CUSTOMER WHERE name= '" +newname+"'");
			res.first();
			cust.setName(res.getString(1));
			 cust.setUsername(res.getString(3));
			 cust.setPassword(res.getString(2));
			 cust.setMail(res.getString(4));
			 cust.setCust_id(res.getInt(5));
			 cust.setFav1(res.getString(6));
			 cust.setFav2(res.getString(7));
			 cust.setFav3(res.getString(8));
			 cust.setUlt1(res.getString(9));
			 cust.setUlt2(res.getString(10));
			 cust.setUlt3(res.getString(11));
			 request.getSession().setAttribute("Nombre",res.getString(1));
			 request.getSession().setAttribute("Usuario",res.getString(3));
			 request.getSession().setAttribute("Mail",res.getString(4));
			 request.getSession().setAttribute("Password",res.getString(2));
			getServletContext()
			.getRequestDispatcher("/BienEditado.jsp")
			.forward(request, response);
		
			con.close();
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
	}

}
