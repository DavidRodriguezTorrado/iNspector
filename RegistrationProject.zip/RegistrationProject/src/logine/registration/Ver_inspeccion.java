package logine.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Ver_inspeccion")
public class Ver_inspeccion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Ver_inspeccion() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		Inspeccion local = new Inspeccion();
		
		try {
			Connection con;
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			String user = "dbadmin";
			String pw = "tortuga";
			con = DriverManager.getConnection(url, user, pw);
			Statement s = con.createStatement();
			
			String query = "SELECT * FROM inspecciones_isst WHERE inspecciones_isst_id = '" + id + "'";
			ResultSet res = s.executeQuery(query);
			
			res.first();
			local.setId(res.getInt(1));
			local.setRotulo(res.getString(2));
			local.setDireccion(res.getString(3));
			local.setActividad(res.getString(4));
			local.setFecha(res.getString(5));
			local.setTipo_actuacion(res.getString(6));
			local.setPerfil_actividad(res.getString(7));
			local.setEstado_sanitario(res.getString(8));
			local.setF_inspeccion(res.getString(9));
			
			Statement s2 = con.createStatement();
			
			ResultSet rs = s2.executeQuery("SELECT id FROM locales WHERE rotulo= '" +res.getString(2)+ "'and direccion='"+res.getString(3)+"'");
			rs.next();
			
			request.setAttribute("id_local", rs.getInt(1));
			
			con.close();
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
		
		request.setAttribute("local", local);
		
		getServletContext()
		.getRequestDispatcher("/DisplayLocal.jsp")
		.forward(request, response);	
	}

}
