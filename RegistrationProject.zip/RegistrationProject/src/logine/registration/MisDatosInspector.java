package logine.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


/**
 * Servlet implementation class Display
 */
@WebServlet("/MisDatosInspector")
public class MisDatosInspector extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MisDatosInspector() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String NRP =(String)request.getSession().getAttribute("NRPInspector");
		String newname = request.getParameter("name1");
		String newmail = request.getParameter("mail1");
		String newpassword = request.getParameter("password1");
		
		try {
			Inspector insp = new Inspector(newname, newpassword, NRP, newmail);
			request.setAttribute("insp", insp);
			Connection con;
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			String user = "dbadmin";
			String pw = "tortuga";
			con = DriverManager.getConnection(url, user, pw);
			PreparedStatement ps = con.prepareStatement("UPDATE inspectores SET nombre='"+newname+"', email='"+newmail+"', contraseña='"+newpassword+"'" 
					+ "WHERE NRP='"+NRP+"'");
			ps.executeUpdate();

			Statement s = con.createStatement();
			ResultSet res = s.executeQuery("SELECT * FROM INSPECTORES WHERE NRP= '" +NRP+"'");
			res.first();
			insp.setName(res.getString(1));
			insp.setMail(res.getString(4));
			insp.setPassword(res.getString(2));
			 request.getSession().setAttribute("NombreInspector",res.getString(1));
			 request.getSession().setAttribute("NRPInspector",res.getString(3));
			 request.getSession().setAttribute("MailInspector",res.getString(4));
			 request.getSession().setAttribute("PasswordInspector",res.getString(2));
			getServletContext()
			.getRequestDispatcher("/BienEditado.jsp")
			.forward(request, response);
		
			con.close();
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
	}

}
