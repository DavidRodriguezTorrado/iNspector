package logine.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Buscador
 */
@WebServlet("/Buscador")


public class Buscador extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Buscador() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/Buscador.jsp";
		
		String rotulo = request.getParameter("rotulo");
		
		List<String> rotulos = askDB(rotulo);
		
		request.setAttribute("rotulos", rotulos);
		
		getServletContext()
		.getRequestDispatcher(url)
		.forward(request, response);
		
	}
	
	protected List<String> askDB(String rotulo) {
		List<String> rotulos = new ArrayList<String>();
		
		try {
			Connection con;
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
			String user = "dbadmin";
			String pw = "tortuga";
			
			con = DriverManager.getConnection(url, user, pw);
			
			Statement s = con.createStatement();
			
			String query = "SELECT DISTINCT rótulo FROM inspecciones_isst WHERE rótulo like '%" + rotulo + "%' ORDER BY rótulo";
			
			ResultSet res = s.executeQuery(query);
			
			while ( res.next() ) {
                rotulos.add(res.getString(1));
            }
			
			con.close();
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
		finally {
			return rotulos;
		}
	}

}

