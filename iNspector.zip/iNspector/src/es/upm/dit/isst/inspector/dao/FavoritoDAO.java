package es.upm.dit.isst.inspector.dao;

import java.util.List;

import es.upm.dit.isst.inspector.model.Favorito;

public interface FavoritoDAO {

	public void create(Favorito favorito);
	public Favorito read(int id);
	public void update(Favorito favorito);
	public void delete(String local);
	public List<Favorito> readAll();

}
