package es.upm.dit.isst.inspector.dao;

import java.util.List;

import es.upm.dit.isst.inspector.model.Ultimo;

public interface UltimoDAO {

	public void create(Ultimo ultimo);
	public Ultimo read(int id);
	public void update(Ultimo ultimo);
	public void delete(int id);
	public List<Ultimo> readAll();

}
