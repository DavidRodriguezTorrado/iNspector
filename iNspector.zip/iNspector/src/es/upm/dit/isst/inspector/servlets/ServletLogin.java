package es.upm.dit.isst.inspector.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.inspector.dao.CustomerDAOImplementation;
import es.upm.dit.isst.inspector.dao.IncidenciaDAOImplementation;
import es.upm.dit.isst.inspector.dao.InspectorDAOImplementation;
import es.upm.dit.isst.inspector.model.Customer;
import es.upm.dit.isst.inspector.model.Incidencia;
import es.upm.dit.isst.inspector.model.Inspector;
import es.upm.dit.isst.inspector.model.Admin;

/**
 * Servlet implementation class Login
 */
@WebServlet("/ServletLogin")
public class ServletLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String ADMIN_EMAIL = "root";
	private final String ADMIN_PASSWORD = "root";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletLogin() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		//List<Customer> customers = (List<Customer>)CustomerDAOImplementation.getInstance().readAll();
		//List<Inspector> inspectores = (List<Inspector>) InspectorDAOImplementation.getInstance().readAll();
		Inspector inspector = InspectorDAOImplementation.getInstance().login(email, password);
		Customer customer = CustomerDAOImplementation.getInstance().login(email, password);
		System.out.println(customer);
		System.out.println(inspector);

		if( ADMIN_EMAIL.equals(email) && ADMIN_PASSWORD.equals(password) ) {
			req.getSession().setAttribute("admin", true);
			Admin admin = new Admin();
			//req.getSession().setAttribute("customers", customers);
			//req.getSession().setAttribute("inspectores", inspectores);
			List <Inspector> inspectores = new ArrayList<Inspector>(); 
			List<String> noautorizados = InspectorDAOImplementation.getInstance().inspectoresNoAutorizados();
			for (int i=1; i<=noautorizados.size(); i++){
				String n=noautorizados.get(i-1);
				Inspector insp= InspectorDAOImplementation.getInstance().read(n);
				inspectores.add(insp); 

			}
			admin.setInspectoresPorAutorizar(inspectores);
			req.getSession().setAttribute("Registrado", "admin");
			req.getSession().setAttribute("admin", admin);
			System.out.println(inspectores);
			req.getSession().setAttribute("noAutorizados", inspectores);
			getServletContext().getRequestDispatcher("/Conf-Administrador.jsp").forward(req,resp);
		} else if ( null != customer.getEmail() ) {
			req.getSession().setAttribute("customer", CustomerDAOImplementation.getInstance().read(customer.getEmail()));
			req.getSession().setAttribute("Name", customer.getName());
			req.getSession().setAttribute("Email", customer.getEmail());
			req.getSession().setAttribute("Password", customer.getPassword());
			System.out.println(customer.getEmail());
			ArrayList<Integer> incidenciasint= IncidenciaDAOImplementation.getInstance().misIncidencias(email);
			System.out.println(incidenciasint);
			List<Incidencia> incidencias= new ArrayList<Incidencia>();
			
			for (int i=1; i<=incidenciasint.size(); i++){
				int n=incidenciasint.get(i-1);
				Incidencia inc= IncidenciaDAOImplementation.getInstance().read(n);
				incidencias.add(inc); 

			}
			customer.setIncidencias(incidencias);
			//System.out.prinln(customer.getIncidencias());
			System.out.println(incidencias.get(0));
			req.getSession().setAttribute("misIncidencias", incidencias);
			if(incidencias.size()>=1) {
				req.getSession().setAttribute("Incidencia1", incidencias.get(0).getId());
				req.getSession().setAttribute("IncidenciaLocal1", IncidenciaDAOImplementation.getInstance().readLocal(incidencias.get(0).getId()).getRotulo());
				req.getSession().setAttribute("Incidencia2", 0);
				req.getSession().setAttribute("IncidenciaLocal2", 0);
				req.getSession().setAttribute("Incidencia3", 0);
				req.getSession().setAttribute("IncidenciaLocal3", 0);

			}
			if(incidencias.size()>=2) {
				req.getSession().setAttribute("Incidencia2", incidencias.get(1).getId());
				req.getSession().setAttribute("IncidenciaLocal2", IncidenciaDAOImplementation.getInstance().readLocal(incidencias.get(1).getId()).getRotulo());
				req.getSession().setAttribute("Incidencia3", 0);
				req.getSession().setAttribute("IncidenciaLocal3", 0);

			} if(incidencias.size()>=3) {

				req.getSession().setAttribute("Incidencia3", incidencias.get(2).getId());
				req.getSession().setAttribute("IncidenciaLocal3", IncidenciaDAOImplementation.getInstance().readLocal(incidencias.get(2).getId()).getRotulo());

			}

			req.getSession().setAttribute("Registrado", "si");
			getServletContext().getRequestDispatcher("/Conf-Usuario.jsp").forward(req,resp);
		} else if ( null != inspector.getEmail() ) {
			req.getSession().setAttribute("inspector", InspectorDAOImplementation.getInstance().read(inspector.getEmail()));
			req.getSession().setAttribute("Name", inspector.getName());
			req.getSession().setAttribute("Email", inspector.getEmail());
			req.getSession().setAttribute("Password", inspector.getPassword());
			req.getSession().setAttribute("Autorizado", inspector.getAutorizado());
			String autorizado = (String)req.getSession().getAttribute("Autorizado");
			System.out.println(autorizado);
			req.getSession().setAttribute("Registrado", "inspector");	
				if(autorizado == "no") {
					req.getSession().setAttribute("Registrado", "inspector_noautorizado");
			}
			getServletContext().getRequestDispatcher("/Conf-Inspector.jsp").forward(req,resp);
		} else {
			getServletContext().getRequestDispatcher("/MalLog.jsp").forward(req,resp);
			req.getSession().setAttribute("Registrado", "no");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}
